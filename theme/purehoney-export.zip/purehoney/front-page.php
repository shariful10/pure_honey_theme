<?php
/**
 * Homepage template — full pre-built layout
 * All sections render automatically on activation
 */
defined('ABSPATH') || exit;



get_header();
$shop_url     = function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : home_url('/shop');
$about_url    = home_url('/about-us');
$dir          = get_template_directory_uri();
?>

<!-- ══ HERO: LEFT-ALIGNED EDITORIAL BANNER ══ -->
<section class="ph-hero relative w-full min-h-[620px] lg:min-h-[720px] flex items-center justify-start text-left bg-cover bg-right overflow-hidden" 
         id="home-hero"
         style="background-image: url('<?php echo esc_url( get_stylesheet_directory_uri() . '/assets/images/hero-banner.jpg' ); ?>');">
  <!-- Directional Gradient Overlay (Warm ivory reading canvas on left, clear on right for glowing glassware) -->
  <div class="ph-hero__scrim absolute inset-0 pointer-events-none" 
       style="background: linear-gradient(to right, rgba(250, 246, 240, 0.98) 0%, rgba(250, 246, 240, 0.92) 25%, rgba(250, 246, 240, 0.55) 55%, rgba(250, 246, 240, 0.15) 100%);"></div>

  <!-- Left-Aligned Content Wrapper -->
  <div class="ph-hero__content relative z-10 w-full max-w-xl xl:max-w-2xl ml-6 lg:ml-16 xl:ml-24 mr-auto px-4 sm:px-6 py-12 lg:py-16 flex flex-col items-start text-left" data-ph-animate>
    <!-- Tagline Pill -->
    <div class="ph-hero__tagline-pill">
      <span>✨</span> NATURE'S GOLD, ELEGANTLY DISPENSED
    </div>

    <!-- Headline -->
    <h1 class="ph-hero__title text-4xl sm:text-5xl lg:text-6xl font-bold text-[#1C1917]">
      Where <span class="ph-hero__highlight text-[#D97706]">Honey Meets</span><br>Artisan Elegance
    </h1>

    <!-- Description -->
    <p class="ph-hero__desc max-w-xl text-[#4A3E39] text-lg font-medium leading-relaxed my-4">
      Discover our curated collection of handcrafted honey dispensers, luxury gift sets, and kitchen essentials — for those who believe every moment deserves beauty.
    </p>

    <!-- Action Buttons -->
    <div class="ph-hero__actions flex flex-row items-center gap-4 mt-2 mb-8">
      <a href="<?php echo esc_url($shop_url); ?>" class="ph-btn ph-btn--primary ph-btn--lg">
        Shop the Collection →
      </a>
      <a href="<?php echo esc_url($about_url); ?>" class="ph-btn ph-btn--secondary ph-btn--lg">Our Story</a>
    </div>

    <!-- Trust Badges Row -->
    <div class="ph-hero__trust-row">
      <div class="ph-hero__trust-badge hero-floating-badge-1 badge-rating">
        <span class="ph-hero__trust-icon">⭐</span>
        <div class="ph-hero__trust-text">
          <strong>4.9/5 Rating</strong>
          <small>2,000+ Reviews</small>
        </div>
      </div>
      <div class="ph-hero__trust-badge hero-floating-badge-2 badge-shipping">
        <span class="ph-hero__trust-icon">🚀</span>
        <div class="ph-hero__trust-text">
          <strong>Fast Shipping</strong>
          <small>2–4 Business Days</small>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ══ TRUST BAR ══ -->
<?php echo do_shortcode('[ph_trust_bar]'); ?>

<!-- ══ SHOP BY CATEGORY ══ -->
<section class="ph-section ph-section--cream" id="shop-categories" style="padding-top: 60px; padding-bottom: 60px;">
  <div class="ph-container">
    <div class="ph-section-title text-center" data-ph-animate style="margin-bottom: 40px;">
      <h2 style="display:flex; align-items:center; justify-content:center; gap:20px;">
        <span style="height:1px; width:60px; background:var(--accent-gold);"></span>
        Shop by Category
        <span style="height:1px; width:60px; background:var(--accent-gold);"></span>
      </h2>
      <p style="color:var(--text-secondary); font-size:0.95rem; font-style:italic; margin-top:8px;">Find your favorite natural products</p>
    </div>
    
    <div class="ph-shop-cats" data-ph-stagger>
      <?php
      $cat_defaults = [
          'gift-boxes'       => ['name' => 'Gift Boxes',       'img' => 'gift-boxes.jpg'],
          'honey-dispensers' => ['name' => 'Honey Dispensers', 'img' => 'honey-dispensers.jpg'],
          'handpicked-honey' => ['name' => 'Handpicked Honey', 'img' => 'handpicked-honey.jpg'],
          'essentials'       => ['name' => 'Essentials',       'img' => 'essentials.jpg'],
      ];
      foreach ($cat_defaults as $cat_slug => $defaults) {
          $term = get_term_by('slug', $cat_slug, 'product_cat');

          // Always use dedicated category images as primary fallback
          $fallback_img = get_template_directory_uri() . '/assets/images/categories/' . $defaults['img'];

          if ($term && !is_wp_error($term)) {
              $thumbnail_id = get_term_meta($term->term_id, 'thumbnail_id', true);
              $image_url = ($thumbnail_id && wp_get_attachment_url($thumbnail_id))
                  ? wp_get_attachment_url($thumbnail_id)
                  : $fallback_img;
              $cat_link = get_term_link($term);
              $cat_name = $term->name;
          } else {
              $cat_name  = $defaults['name'];
              $image_url = $fallback_img;
              $cat_link  = wc_get_page_permalink('shop') ?: home_url('/shop/');
          }
          ?>
          <a href="<?php echo esc_url($cat_link); ?>" class="ph-shop-cat-card" data-ph-animate>
            <div class="ph-shop-cat-image-wrap">
              <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($cat_name); ?>">
            </div>
            <h3><?php echo esc_html($cat_name); ?></h3>
          </a>
          <?php
      }
      ?>
    </div>
  </div>
</section>

<!-- ══ FEATURED PRODUCTS ══ -->
<section class="ph-section ph-section--white" id="featured" style="background:#FFFFFF;">
  <div class="ph-container">
    <div class="ph-section-title" data-ph-animate>
      <span class="eyebrow">Handpicked For You</span>
      <h2>Top Picks This Season</h2>
      <p>Our most-loved dispensers and gift sets — crafted for beauty and everyday elegance.</p>
    </div>
    <div data-ph-stagger>
      <?php
      $featured_skus = ['PH-AD-001', 'PH-AD-004', 'PH-AD-002', 'PH-LG-001'];
      $product_ids = [];
      if (function_exists('wc_get_product_id_by_sku')) {
        foreach ($featured_skus as $sku) {
          $id = wc_get_product_id_by_sku($sku);
          if ($id) {
            $product_ids[] = $id;
          }
        }
      }

      $query_args = ['post_type' => 'product', 'posts_per_page' => 4, 'post_status' => 'publish'];
      if (!empty($product_ids)) {
        $query_args['post__in'] = $product_ids;
        $query_args['orderby'] = 'post__in';
      } else {
        $query_args['meta_key'] = '_featured';
        $query_args['meta_value'] = 'yes';
      }

      $q = new WP_Query($query_args);
      if ($q->have_posts()):
        echo '<div class="woocommerce"><ul class="products columns-4">';
        while ($q->have_posts()) {
          $q->the_post();
          if (function_exists('wc_get_template_part')) {
            wc_get_template_part('content', 'product');
          } else {
            get_template_part('template-parts/product-card');
          }
        }
        wp_reset_postdata();
        echo '</ul></div>';
      else:
        echo do_shortcode('[products limit="4" columns="4" orderby="popularity"]');
      endif;
      ?>
    </div>
    <div class="text-center" style="margin-top:40px;" data-ph-animate>
      <a href="<?php echo esc_url($shop_url); ?>" class="ph-btn ph-btn--outline">View All Products →</a>
    </div>
  </div>
</section>

<!-- ══ CATEGORY CARDS ══ -->
<section class="ph-section ph-section--cream" id="categories">
  <div class="ph-container">
    <div class="ph-section-title" data-ph-animate>
      <span class="eyebrow">Browse By Category</span>
      <h2>Explore Our Collections</h2>
    </div>
    <div class="ph-cat-grid" data-ph-stagger>
      <a href="<?php echo esc_url(get_term_link('artisan-dispensers', 'product_cat')); ?>" class="ph-cat-card" data-ph-animate>
        <img src="<?php echo esc_url($dir . '/assets/images/cat-dispensers.jpg'); ?>" alt="Artisan Dispensers" loading="lazy">
        <div class="ph-cat-card__content">
          <span class="ph-cat-card__label">Collection</span>
          <h3 class="ph-cat-card__title">Artisan Dispensers</h3>
          <span class="ph-cat-card__link">Shop Now <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
        </div>
      </a>
      <a href="<?php echo esc_url(get_term_link('luxury-gift-sets', 'product_cat')); ?>" class="ph-cat-card" data-ph-animate>
        <img src="<?php echo esc_url($dir . '/assets/images/cat-gifts.jpg'); ?>" alt="Luxury Gift Sets" loading="lazy" onerror="this.src='<?php echo esc_url($dir . '/assets/images/hero-bg.jpg'); ?>'">
        <div class="ph-cat-card__content">
          <span class="ph-cat-card__label">Collection</span>
          <h3 class="ph-cat-card__title">Luxury Gift Sets</h3>
          <span class="ph-cat-card__link">Shop Now <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
        </div>
      </a>
      <a href="<?php echo esc_url(get_term_link('kitchen-elegance', 'product_cat')); ?>" class="ph-cat-card" data-ph-animate>
        <img src="<?php echo esc_url($dir . '/assets/images/cat-kitchen.jpg'); ?>" alt="Kitchen Elegance" loading="lazy">
        <div class="ph-cat-card__content">
          <span class="ph-cat-card__label">Collection</span>
          <h3 class="ph-cat-card__title">Kitchen Elegance</h3>
          <span class="ph-cat-card__link">Shop Now <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M5 12h14M12 5l7 7-7 7"/></svg></span>
        </div>
      </a>
    </div>
  </div>
</section>

<!-- ══ STORY ══ -->
<section class="ph-section ph-section--white" id="our-story" style="background:#FFFFFF;">
  <div class="ph-container">
    <div class="ph-story">
      <div class="ph-story__visual" data-ph-animate="fade-left">
        <img src="<?php echo esc_url($dir . '/assets/images/cat-dispensers.jpg'); ?>" alt="Artisan honey jars" loading="lazy">
      </div>
      <div class="ph-story__content" data-ph-animate="fade-right">
        <span class="eyebrow">Our Story</span>
        <h2>Born from a Love of<br>Nature's Sweetest Gift</h2>
        <p>PureHoney started with a simple belief: that honey — the world's oldest natural sweetener — deserves to be presented as the treasure it truly is.</p>
        <p>We partnered with artisan craftspeople across Europe and North America to create dispensers and accessories that honor both the bees and the people who love their golden harvest.</p>
        <a href="<?php echo esc_url($about_url); ?>" class="ph-btn ph-btn--primary" style="margin-top:8px;">Read Our Story</a>
        <div class="ph-story__stats">
          <div>
            <span class="ph-story__stat-number" data-ph-count="2000" data-ph-count-suffix="+">2000+</span>
            <span class="ph-story__stat-label">Happy Customers</span>
          </div>
          <div>
            <span class="ph-story__stat-number" data-ph-count="15" data-ph-count-suffix="+">15+</span>
            <span class="ph-story__stat-label">Artisan Products</span>
          </div>
          <div>
            <span class="ph-story__stat-number" data-ph-count="98" data-ph-count-suffix="%">98%</span>
            <span class="ph-story__stat-label">Satisfaction Rate</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ══ BEST SELLERS ══ -->
<section class="ph-section ph-section--cream" id="best-sellers">
  <div class="ph-container">
    <div class="ph-section-title" data-ph-animate>
      <span class="eyebrow">Customer Favourites</span>
      <h2>Best Sellers</h2>
      <p>The products our customers can't stop gifting — or keeping for themselves.</p>
    </div>
    <div data-ph-stagger>
      <?php
      $bs_query = new WP_Query([
        'post_type'      => 'product',
        'posts_per_page' => 8,
        'post_status'    => 'publish',
        'meta_key'       => 'total_sales',
        'orderby'        => 'meta_value_num',
        'order'          => 'DESC',
      ]);

      if (!$bs_query->have_posts()) {
        $bs_query = new WP_Query([
          'post_type'      => 'product',
          'posts_per_page' => 8,
          'post_status'    => 'publish',
          'orderby'        => 'date',
          'order'          => 'DESC',
        ]);
      }

      if ($bs_query->have_posts()):
        echo '<div class="woocommerce"><ul class="products columns-4">';
        while ($bs_query->have_posts()) {
          $bs_query->the_post();
          if (function_exists('wc_get_template_part')) {
            wc_get_template_part('content', 'product');
          } else {
            get_template_part('template-parts/product-card');
          }
        }
        wp_reset_postdata();
        echo '</ul></div>';
      else:
        echo do_shortcode('[products best_selling="true" limit="8" columns="4"]');
      endif;
      ?>
    </div>
  </div>
</section>

<!-- ══ FEATURES ══ -->
<section class="ph-section ph-section--white" id="why-purehoney" style="background:#FFFFFF;">
  <div class="ph-container">
    <div class="ph-section-title" data-ph-animate>
      <span class="eyebrow" style="color:var(--accent-gold);">Why PureHoney</span>
      <h2>Crafted With Intention</h2>
    </div>
    <div class="grid-4" data-ph-stagger>
      <?php
      $features = [
        ['icon'=>'M9.813 15.904 9 18.75l-.813-2.846a4.5 4.5 0 0 0-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 0 0 3.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 0 0 3.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 0 0-3.09 3.09Z', 'title'=>'Pure Materials', 'text'=>'Premium borosilicate glass, natural bamboo, and food-grade materials — always BPA-free.'],
        ['icon'=>'M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12Z', 'title'=>'Crafted with Love', 'text'=>'Every item handpicked by our artisan curators who test for quality, beauty, and elegance.'],
        ['icon'=>'M20.893 13.393l-1.135-1.135a2.252 2.252 0 0 1-.421-.585l-1.08-2.16a.414.414 0 0 0-.663-.107.827.827 0 0 1-.812.21l-1.273-.363a.89.89 0 0 0-.738 1.595l.587.39c.59.395.674 1.23.172 1.732l-.2.2c-.212.212-.33.498-.33.796v.41c0 .409-.11.809-.32 1.158l-1.315 2.191a2.11 2.11 0 0 1-1.81 1.025 1.055 1.055 0 0 1-1.055-1.055v-1.172c0-.92-.56-1.747-1.414-2.089l-.655-.261a2.25 2.25 0 0 1-1.383-2.46l.007-.042a2.25 2.25 0 0 1 .29-.787l.09-.15a2.25 2.25 0 0 1 2.37-1.048l1.178.236a1.125 1.125 0 0 0 1.302-.795l.208-.73a1.125 1.125 0 0 0-.578-1.315l-.665-.332', 'title'=>'Eco Packaging', 'text'=>'100% recyclable packaging. Zero single-use plastic. FSC-certified gift boxes.'],
        ['icon'=>'M8.25 18.75a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h6m-9 0H3.375a1.125 1.125 0 0 1-1.125-1.125V14.25m17.25 4.5a1.5 1.5 0 0 1-3 0m3 0a1.5 1.5 0 0 0-3 0m3 0h1.125c.621 0 1.129-.504 1.09-1.124a17.902 17.902 0 0 0-3.213-9.193 2.056 2.056 0 0 0-1.58-.86H14.25M16.5 18.75h-2.25m0-11.177v-.958c0-.568-.422-1.048-.987-1.106a48.554 48.554 0 0 0-10.026 0', 'title'=>'Fast Delivery', 'text'=>'Orders dispatched within 24 hours. Free shipping on orders over $59 with tracking.'],
      ];
      foreach ($features as $f):
      ?>
      <div class="ph-feature" data-ph-animate>
        <div class="ph-feature__icon">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" width="26" height="26"><path stroke-linecap="round" stroke-linejoin="round" d="<?php echo esc_attr($f['icon']); ?>"/></svg>
        </div>
        <h3 class="ph-feature__title"><?php echo esc_html($f['title']); ?></h3>
        <p class="ph-feature__text"><?php echo esc_html($f['text']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ TESTIMONIALS ══ -->
<section class="ph-section ph-section--cream" id="reviews">
  <div class="ph-container">
    <div class="ph-section-title" data-ph-animate>
      <span class="eyebrow">Real Reviews</span>
      <h2>What Our Customers Say</h2>
    </div>
    <div class="grid-3" data-ph-stagger>
      <?php
      $reviews = [
        ['text'=>'"I bought the Hexagonal Glass Honey Jar as a birthday gift and the recipient absolutely loved it. Beautifully packaged, arrived perfectly safe, and looks stunning on her counter."','name'=>'Sarah M.','meta'=>'Verified Buyer · New York, USA'],
        ['text'=>'"The Golden Harvest Gift Set is worth every penny. The quality is exceptional — each jar is thick glass and the lids seal perfectly. My mother-in-law was over the moon."','name'=>'James R.','meta'=>'Verified Buyer · London, UK'],
        ['text'=>'"I\'ve been using the Amber Glass Honey Dispenser with Pump for 3 months now. Zero drips, easy to clean, and looks gorgeous on my kitchen shelf. Would buy again!"','name'=>'Priya K.','meta'=>'Verified Buyer · Toronto, Canada'],
      ];
      foreach ($reviews as $r):
      ?>
      <div class="ph-testimonial" data-ph-animate>
        <div class="ph-testimonial__stars">
          <?php for ($i = 0; $i < 5; $i++): ?>
          <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" width="16" height="16"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill="#D97706"/></svg>
          <?php endfor; ?>
        </div>
        <p class="ph-testimonial__text"><?php echo esc_html($r['text']); ?></p>
        <div class="ph-testimonial__author">
          <div style="width:44px;height:44px;border-radius:50%;background:var(--ph-gold-gradient);display:flex;align-items:center;justify-content:center;color:#FFFFFF;font-weight:800;font-size:1.125rem;flex-shrink:0;">
            <?php echo esc_html(substr($r['name'], 0, 1)); ?>
          </div>
          <div>
            <p class="ph-testimonial__name"><?php echo esc_html($r['name']); ?></p>
            <p class="ph-testimonial__meta"><?php echo esc_html($r['meta']); ?></p>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ══ NEWSLETTER ══ -->
<section class="ph-newsletter" id="newsletter">
  <div class="ph-container">
    <div class="ph-newsletter__inner" data-ph-animate>
      <span class="eyebrow" style="color:var(--accent-gold);">Stay in the Loop</span>
      <h2 class="ph-newsletter__title">Get 10% Off Your First Order</h2>
      <p class="ph-newsletter__subtitle">Subscribe for exclusive deals, new arrivals, and honey lifestyle inspiration.</p>
      <form class="ph-newsletter__form" novalidate>
        <input type="email" class="ph-newsletter__input" placeholder="Enter your email address…" required autocomplete="email">
        <button type="submit" class="ph-btn ph-btn--primary">Subscribe</button>
      </form>
      <p style="font-size:0.8125rem;color:var(--text-muted);margin-top:14px;margin-bottom:0;">No spam, ever. Unsubscribe anytime.</p>
    </div>
  </div>
</section>

<!-- User Content (Elementor or Block Editor) -->
<div class="ph-container ph-user-content" style="margin-top: 40px; margin-bottom: 40px;">
  <?php while (have_posts()) : the_post(); the_content(); endwhile; ?>
</div>

<?php get_footer(); ?>
